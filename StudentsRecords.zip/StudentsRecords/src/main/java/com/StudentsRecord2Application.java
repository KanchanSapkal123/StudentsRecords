package com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentsRecord2Application {

	public static void main(String[] args) {
		SpringApplication.run(StudentsRecord2Application.class, args);
	}

}
